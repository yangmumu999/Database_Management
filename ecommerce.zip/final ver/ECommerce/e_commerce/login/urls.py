from django.urls import path

from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('register', views.register, name='register'),
    path('check_type', views.check_type, name='check_type'),
    
    path('register_business', views.register_business, name='register_business'),
    path('register_home', views.register_home, name='register_home'),
    
    path('register_business_index', views.register_business_index, name='register_business_index'),
    path('register_home_index', views.register_home_index, name='register_home_index'),
    path('register_success', views.register_success, name='register_success'),
    path('test', views.test, name='test'),
    path('login', views.my_login, name='login'),
    path('logout', views.my_logout, name='logout'),
    path('login_confirm', views.login_confirm, name='login_confirm'),
    path('login_success', views.login_success, name='login_success'),

    path('user_profile', views.user_profile, name='user_profile'),
    path('user_page', views.user_page, name='user_page'),
    
    path('product1', views.product1, name='product1'),
    path('product2', views.product2, name='product2'),
    path('product3', views.product3, name='product3'),
    
    path('purchase_success', views.purchase_success, name='purchase_success'),
    path('ordered_products', views.ordered_products, name='ordered_products'),
    path('searching', views.searching, name='searching'),
    path('searching_item', views.searching_item, name='searching_item'),
]