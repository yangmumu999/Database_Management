import datetime

from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

# Create your models here.
class Address(models.Model): 
     
    address_id = models.AutoField(primary_key=True)
    
    zip_code = models.IntegerField(null = True)
    city = models.CharField(max_length=30, null = True)
    
    state = models.CharField(max_length=30, null = True)
    street = models.CharField(max_length=30, null = True)
    
    def __str__(self):
        return self.address_id

class Customer(models.Model):
     
    customer_id = models.AutoField(primary_key=True)
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    
    username = models.CharField(max_length=30, null=False)
    password = models.CharField(max_length=32, null=False)
    
    first_name = models.CharField(max_length=30, null = True)
    last_name = models.CharField(max_length=30, null = True)
    
    marriage_status = models.CharField(max_length=30, null = True)
    gender = models.CharField(max_length=30, null = True)
    age = models.IntegerField(null = True)
    income = models.CharField(max_length=30, null = True)
    
    business_category = models.CharField(max_length=30, null = True)
    company_gross_annual_income = models.CharField(max_length=30, null = True)
    
    type = models.CharField(max_length=10, null=False)
    # customer_address = models.ForeignKey(Address, on_delete=models.CASCADE)
    # balance = models.IntegerField(default = 10000)
    
    def __str__(self):
        return (str(self.customer_id)+" "+self.username)

class Product(models.Model):
    
    product_id = models.AutoField(primary_key=True)
    
    name = models.CharField(max_length=30, null=False)
    price = models.IntegerField(null = True)
    inventory_amount = models.IntegerField(null = True)
    product_kind = models.CharField(max_length=30, null= True)
    link_address = models.CharField(max_length=100, null= True)
    
    def __str__(self):
        return (str(self.product_id)+" "+self.name)

class Transaction(models.Model): 
    
    order_number = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.CharField(max_length=30, null=True)
    # salesperson_name = models.ForeignKey(Salesperson, on_delete=models.CASCADE)
    quantity = models.IntegerField(null = True)
    product_information = models.ForeignKey(Product, on_delete=models.CASCADE)
    customer_information = models.ForeignKey(Customer, on_delete=models.CASCADE)
    
    def __str__(self):
        return (str(self.order_number))
    
class Region(models.Model):
     
    region_id = models.AutoField(primary_key=True)
    
    region_name = models.CharField(max_length=30, null = True)
    region_manager = models.CharField(max_length=30, null = True)
    
    def __str__(self):
        return self.region_id

class Store(models.Model):
     
    store_id = models.AutoField(primary_key=True)
    
    manager = models.CharField(max_length=30, null = True)
    number_of_salespersons = models.CharField(max_length=30, null = True)
    region = models.ForeignKey(Region, on_delete=models.CASCADE)
    store_address = models.ForeignKey(Address, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.store_id
    
class Salesperson(models.Model):
    salesperson_id = models.AutoField(primary_key=True)
    
    salary = models.IntegerField(null = True)
    store_assigned = models.ForeignKey(Store, on_delete=models.CASCADE)
    
    e_mail = models.CharField(max_length=30, null = True)
    job_title = models.CharField(max_length=30, null = True)
    name = models.CharField(max_length=30, null = True)
    salesperson_address = models.ForeignKey(Address, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.salesperson_id
    
