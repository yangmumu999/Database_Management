# from django.contrib import admin
# from . models import Address, Region, Store, Salesperson

# # Register your models here.
# admin.site.register(Address)
# admin.site.register(Region)
# admin.site.register(Store)
# admin.site.register(Salesperson)