from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from django.http import HttpResponse

# Create your views here.

def index(request):
    return render(request, 'purchase/index.html')
def product1(request):
    return render(request, 'purchase/product1.html')
def product2(request):
    return render(request, 'purchase/product2.html')
def product3(request):
    return render(request, 'purchase/product3.html')
def product4(request):
    return render(request, 'purchase/product4.html')
def product5(request):
    return render(request, 'purchase/product5.html')
def product6(request):
    return render(request, 'purchase/product6.html')
def product7(request):
    return render(request, 'purchase/product7.html')
def product8(request):
    return render(request, 'purchase/product8.html')
def product9(request):
    return render(request, 'purchase/product9.html')
def product10(request):
    return render(request, 'purchase/product10.html')