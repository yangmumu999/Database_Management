import hashlib
import json
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from django.http import HttpResponse
from . models import Customer, Product, Transaction
from django.contrib import auth
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.db.models import Max

# Create your views here.

def main(request):
    return render(request, 'login/index.html')
    
def register(request):
    return render(request, 'login/register.html')

@login_required()
def user_profile(request):
    
    user_id = request.session.get('_auth_user_id')
    user = User.objects.get(pk=user_id)
    transaction = Transaction.objects.filter(user=user_id)
    
    return render(request, 'login/user_profile.html', locals())

def my_login(request):
    return render(request, 'login/login.html')
    
def my_logout(request):
    auth.logout(request)
    return render(request, 'login/index.html')

def check_type(request):
    
    if request.method=="POST":
        business_type = request.POST.get("business_type")
    if business_type == "Business":
        return redirect('register_business_index')
    else:
        return redirect('register_home_index')

def register_business_index(request):
    return render(request, 'login/register_business_index.html')

def register_home_index(request):
    return render(request, 'login/register_home_index.html')
    
def register_business(request):
    
    if request.method=="POST":
        
        customer = Customer()
        username = request.POST.get("username")
        password = request.POST.get("password")
        business_category = request.POST.get("business_category")
        company_gross_annual_income = request.POST.get("company_income")
        
        md5 = hashlib.md5()
        md5.update(password.encode())
        saltpassword = md5.hexdigest()
        
        userinfo = {"username":username, "password":saltpassword}
        user = User.objects.create_user(**userinfo)
        user.save()
        
        customer.username = username
        customer.business_category = business_category
        customer.company_gross_annual_income = company_gross_annual_income
        
        customer.password = saltpassword
        customer.user_id = user
        
        customer.type = "business"
        customer.save()
        

    return render(request, 'login/register_success.html')

def register_home(request):
    
    if request.method=="POST":
        
        first_name = request.POST.get("firstname")
        last_name = request.POST.get("lastname")
        age = request.POST.get("age")
        gender = request.POST.get("gender")
        marriage_status = request.POST.get("marriage_status")
        annual_income = request.POST.get("income")
        username = request.POST.get("username")
        password = request.POST.get("password")
        
        md5 = hashlib.md5()
        md5.update(password.encode())
        saltpassword = md5.hexdigest()
        
        userinfo = {"username":username, "password":saltpassword}
        user = User.objects.create_user(**userinfo)
        user.save()
        
        customer = Customer()
        customer.first_name = first_name
        customer.last_name = last_name
        customer.age = age
        customer.gender = gender
        customer.marriage_status = marriage_status
        customer.income = annual_income
        customer.username = username
        
        customer.password = saltpassword
        customer.user_id = user
        
        customer.type = "home";
        customer.save()
        
        return render(request, 'login/register_success.html')
    
def register_success(request):
    return render(request, 'login/register_success.html')

def login_confirm(request):
   
    if request.method=="POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        md5 = hashlib.md5()
        md5.update(password.encode())
        pwd = md5.hexdigest()
        
        customer = Customer.objects.filter(username=username).first()
        
        if not customer:
            # messages.warning(request, "Username not exist")
            return HttpResponse("Username does not exist, please return to the login page")

        user = auth.authenticate(username = username, password = pwd)
        
        if user is not None:
            auth.login(request, user)
            return redirect("login_success")
        else:
            # messages.warning(request, "Incorrect username or password")
            return HttpResponse("Incorrect username or password, please return to the login page")
            return redirect("login")
        
def login_success(request):
    return render(request, 'login/login_success.html')

def user_page(request):
    return render(request, 'login/index2.html')

def test(request):
    return render(request, 'login/test.html')

def product1(request):
    product = Product.objects.get(pk=1)
    return render(request, 'login/product.html', {"product":product})

def product2(request):
    product = Product.objects.get(pk=2)
    return render(request, 'login/product.html', {"product":product})

def product3(request):
    product = Product.objects.get(pk=3)
    return render(request, 'login/product.html', {"product":product})

def purchase_success(request):
    
    user_id = request.session.get('_auth_user_id')
    user = User.objects.get(pk=user_id)
    customer = Customer.objects.filter(username=user.username).first()
    
    if request.method=="POST":
        purchase_num = request.POST.get("number")
        product_id = request.POST.get("product_id")
        
        product = Product.objects.get(pk=product_id)
        ori_amount = product.inventory_amount
        product.inventory_amount = ori_amount - (int)(purchase_num)
        product.save()
        
        transaction = Transaction()
        transaction.user = user
        transaction.date = timezone.now().strftime("%Y-%m-%d")
        transaction.quantity = purchase_num
        transaction.product_information = product
        transaction.customer_information = customer
        
        transaction.save()
      
    return render(request, 'login/purchase_success.html')

def ordered_products(request):
    ordered_products = Product.objects.order_by('price')
    expensive_product = Product.objects.all().aggregate(Max('price'))
    return render(request, 'login/ordered_products.html',locals())

def searching(request):
    return render(request, 'login/searching.html')

def searching_item(request):
    if request.method=="POST":
        try:
            product = request.POST.get("product")
        except Exception as e:
            product = None
        if not product:
            return HttpResponse("Product does not exist, please return to the searching page")
        else:

            try:
                aimed_product = Product.objects.get(name=product)
            except Exception as e:
                aimed_product = None  
            return render(request, 'login/searching_item.html',{'aimed_product': aimed_product})
    return redirect('product2')
