# import datetime

# from django.db import models
# from django.utils import timezone
# from django.contrib.auth.models import User
    
# # Create your models here.

# class Address(models.Model):
     
#     address_id = models.AutoField(primary_key=True)
    
#     zip_code = models.IntegerField(null = True)
#     city = models.CharField(max_length=30, null = True)
    
#     state = models.CharField(max_length=30, null = True)
#     street = models.CharField(max_length=30, null = True)
    
#     def __str__(self):
#         return address_id




# class Region(models.Model):
     
#     region_id = models.AutoField(primary_key=True)
    
#     region_name = models.CharField(max_length=30, null = True)
#     region_manager = models.CharField(max_length=30, null = True)
    
#     def __str__(self):
#         return region_id




# class Store(models.Model):
     
#     store_id = models.AutoField(primary_key=True)
    
#     manager = models.CharField(max_length=30, null = True)
#     number_of_salespersons = models.CharField(max_length=30, null = True)
#     region = models.CharField(max_length=30, null = True)
    
#     def __str__(self):
#         return store_id




# class Salesperson(models.Model):
#     salesperson_id = models.AutoField(primary_key=True)
    
#     salary = models.IntegerField(null = True)
#     store_assigned = models.ForeignKey(Store, on_delete=models.CASCADE)
    
#     e-mail = models.CharField(max_length=30, null = True)
#     job_title = models.CharField(max_length=30, null = True)
#     name = models.CharField(max_length=30, null = True)
#     salesperson_address = models.ForeignKey(Address, on_delete=models.CASCADE)
#     salesperson_transaction = models.ForeignKey(Transaction, on_delete=models.CASCADE)
    
#     def __str__(self):
#         return salesperson_id